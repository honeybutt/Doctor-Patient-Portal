from src.common.database import Database
from src.models.addPatient import Blog
from src.models.report import Post
from src.models.user import Patient
from src.models.patient import PatientUser


# from src.models.patient import PatientUser
__author__ = 'jslvtr'


from flask import Flask, render_template, request, session, make_response

app = Flask(__name__)  # '__main__'
app.secret_key = "Psycho"


@app.route('/')
def home_template():
    return render_template('home.html')



@app.route('/register')
def register_template():
    return render_template('register.html')

@app.route('/contactSehat')
def contact_template():
    return render_template('contactSehat.html')

@app.route('/contactSehatPatient')
def contactSehatPatient_template():
    return render_template('contactSehatPatient.html')

@app.route('/bookAppointment')
def bookAppointment_template():
    return render_template('bookAppointment.html')

@app.route('/doctorList')
def doctorListPatient_template():
    return render_template('doctorList.html')

@app.route('/contactPatient')
def contactPatient_template():
    return render_template('contactP.html')

@app.route('/contactDoctor')
def contactDoctor_template():
    return render_template('contactDoctor.html')

@app.route('/doctorList')
def doctorList_template():
    return render_template('doctorList.html')

@app.route('/auth/register', methods=['POST'])
def register_user():
    email = request.form['email']
    password = request.form['password']

    Patient.register(email, password)

    return render_template("profile.html", email=session['email'])



@app.route('/login')
def login_template():
    return render_template('login.html')

@app.route('/auth/login', methods=['POST'])
def login_user():
    email = request.form['email']
    password = request.form['password']

    if Patient.login_valid(email, password):
        Patient.login(email)
    else:
        session['email'] = None
        return render_template("404.html")

    return render_template("profile.html", email=session['email'])



@app.before_first_request
def initialize_database():
    Database.initialize()




@app.route('/loginPatient')
def login_patient_template():
    return render_template('loginPatient.html')


@app.route('/auth/loginPatient', methods=['POST'])
def login_patient_user():
    email = request.form['email']
    password = request.form['password']

    if PatientUser.login_valid(email, password):
        PatientUser.login(email)
    else:
        session['email'] = None

    return render_template("profilePatient.html", email=session['email'])


@app.route('/registerPatient')
def register_patient_template():
    return render_template('registerPatient.html')


@app.route('/auth/registerPatient', methods=['POST'])
def register_patient_user():
    email = request.form['email']
    password = request.form['password']

    PatientUser.register(email, password)

    return render_template("profilePatient.html", email=session['email'])



@app.route('/patDetail/<string:user_id>')
@app.route('/patDetail')
def user_blogs(user_id=None):
    if user_id is not None:
        user = Patient.get_by_id(user_id)
    else:
        user = Patient.get_by_email(session['email'])

    blogs = user.get_blogs()

    return render_template("user_patDetail.html", blogs=blogs, email=user.email)


@app.route('/patDetail/new', methods=['POST', 'GET'])
def create_new_blog():
    if request.method == 'GET':
        return render_template('new_pat.html')
    else:
        title = request.form['title']
        description = request.form['description']
        user = Patient.get_by_email(session['email'])

        new_blog = Blog(user.email, title, description, user._id)
        new_blog.save_to_mongo()

        return make_response(user_blogs(user._id))


@app.route('/posts/<string:blog_id>')
def blog_posts(blog_id):
    blog = Blog.from_mongo(blog_id)
    posts = blog.get_posts()

    return render_template('reports.html', posts=posts, blog_title=blog.title, blog_id=blog._id)


@app.route('/pDetail/new/<string:blog_id>', methods=['POST', 'GET'])
def create_new_post(blog_id):
    if request.method == 'GET':
        return render_template('new_report.html', blog_id=blog_id)
    else:
        title = request.form['title']
        content = request.form['content']
        user = Patient.get_by_email(session['email'])

        new_post = Post(blog_id, title, content, user.email)
        new_post.save_to_mongo()

        return make_response(blog_posts(blog_id))


if __name__ == '__main__':
    app.run(port=4995, debug=True)
